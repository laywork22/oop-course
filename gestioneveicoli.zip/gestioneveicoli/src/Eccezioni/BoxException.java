package Eccezioni;

public class BoxException extends Exception {
    public BoxException() {}

    public BoxException(String message) {
        super(message);
    }
}
