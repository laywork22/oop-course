package Eccezioni;

public class AutorimessaVuotaException extends BoxException {
    public AutorimessaVuotaException(){};

    public AutorimessaVuotaException(String message) {
        super(message);
    }
}
